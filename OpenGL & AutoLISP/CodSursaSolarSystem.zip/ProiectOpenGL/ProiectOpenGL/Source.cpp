#include <GL\glut.h>
#include <Windows.h>
#include <math.h>
#include <time.h>
#include <iostream>

unsigned int Timp = 15;
GLfloat UnghiRotatie = 0.0f; //Unghi de rotatie pentru Soare
GLfloat Unghi = 0.0f; //Unghi de rotatie pentru Planete
GLfloat Vedere = 45.0f; //Initializare perspectiva 

void Initializare(int argc, char** argv);
void Redimensionare(int a, int b);
void Desenare();
void Zoom(int a,int b,int c,int d);
void Soare();
void Orbite();
void Planete(int i);
void Setari_Planete(int i);
void Rotatie();
void timer(int value);

int main(int argc, char** argv) {
	Initializare(argc, argv);  
	glutCreateWindow("OpenGL"); // Creare fereastra
	glClearColor(0.0, 0.0, 0.0, 0.0); //Culoare de fundal ->negru
	glutReshapeFunc(Redimensionare);
	glutDisplayFunc(Desenare);
	glutTimerFunc(0, timer, 0);
	glutMouseFunc(Zoom);
	glutMainLoop();
}

// Initializare_Setari fereastra
void Initializare(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH | GLUT_DOUBLE); //Format de afisare implementat cu 2 buffere
	glutInitWindowPosition(50, 50);
	glutInitWindowSize(1000, 600);
}

void Redimensionare(int a, int b) {
	GLfloat aspect = (GLfloat)a / (GLfloat)b;
	glViewport(0, 0, (GLint)a, (GLint)b);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(Vedere, aspect, 0.01f, 100.0f);
	glMatrixMode(GL_MODELVIEW);
}

void Zoom(int a, int b, int c, int d) {
	// Daca apasam click stanga se largeste perspectiva din care vedem desenul
	if (a == GLUT_LEFT_BUTTON){
		if (b == GLUT_DOWN) {
			Vedere += 1;
			Redimensionare(glutGet(GLUT_WINDOW_WIDTH), glutGet(GLUT_WINDOW_HEIGHT));
		}
	}
	// Daca apasam click dreapta se micsoreaza perspectiva 
	else
		if (a == GLUT_RIGHT_BUTTON) {
			if (b == GLUT_DOWN) {
				Vedere -= 1;
				Redimensionare(glutGet(GLUT_WINDOW_WIDTH), glutGet(GLUT_WINDOW_HEIGHT));
			}
		}
}

// Crearea desenului
void Desenare() {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	Soare();
	Orbite();
	glFlush();
	glutSwapBuffers();
}

// Setari pentru crearea soarelui
void Soare() {
	glLoadIdentity(); 
	glTranslatef(0.0, 1.0, -15.0); // Setam pozitia in spatiu a sferei
	glRotatef(60, 1.0, 0.0, 0.0);  // Setam unghiul de inclinatie a sferei
	glRotatef(UnghiRotatie, 0.0f, 0.0f, 1.0f); // Setam modul de rotatie al sferei 
	glColor3f(1, 1, 0); // Galben -> Culoarea sferei 
	glutWireSphere(1, 30, 36); // Creare sfera
	UnghiRotatie += 0.75f;
}

void Orbite() {
	for (int i = 1; i <= 9; i++) {
		glLoadIdentity();
		glColor3f(1.0, 1.0, 1.0); //Alb -> Culoare orbite
		glTranslatef(0.0,2.0, -30);
		glRotatef(130, 1.0, 0.0, 0.0);
		glutWireTorus(i+1,i+1, 1,100); //Desenare orbite
		Rotatie(); // Rotatie plenete
		Planete(i);
	}
}

void Planete(int i) { //Setare pozitie planete
	if (i % 4==0 )
		glTranslatef(0.0,(GLfloat) -2 * i - 2, 0.0);
	else
		if (i % 4 == 1)
			glTranslatef((GLfloat)2 * i + 2, 0.0, 0.0);
		else
			if (i % 4==2 )
				glTranslatef(0.0, (GLfloat)2 * i + 2, 0.0);
			else
				glTranslatef((GLfloat)-2 * i - 2, 0.1, 0.0);
	Setari_Planete(i);
}
void Setari_Planete(int i) {
	double r, g, b; // procetanjul de culoare
	double raza;
	if (i >=5)
		raza = (double)i / 7;
	else
		raza =(float)i / 5+0.25;
	srand(time(NULL));
	g = 1.0 / (rand() % 10);
	if (g < 0.25)
		g = 1;
	//Colorare si dimensioanare sfere
	if (i % 5 == 0) {
		r = 1.0 / (rand() % 10);
		if (r < 0.5)
			r = 1;
		glColor3f((GLfloat)r, (GLfloat)g,0.0);
		glutSolidSphere((GLfloat)raza, 20, 26);
	}
	else
		if (i % 5 == 1) {
			r = 1.0 / (rand() % 10);
			if (r < 0.5)
				r = 1;
			glColor3f((GLfloat)r, 0.0, (GLfloat)g);
			glutSolidSphere((GLfloat)raza, 20, 26);
		}
		else
			if (i % 5 == 2) {
				b = 1.0 / (rand() % 10);
				r = 1.0 / (rand() % 10);
				if (b < 0.25)
					b = 1;
				glColor3f((GLfloat)r, (GLfloat)g, (GLfloat)b);
				glutSolidSphere(raza, 30, 36);
			}
			else
				if (i % 5 == 3) {
					b = 1.0 / (rand() % 10);
					r = 1.0 / (rand() % 10);
					if (b < 0.25)
						b = 1;
					glColor3f(1,1, b);
					glutSolidSphere((GLfloat)raza, 30, 36);
				}
			else {
				b = 1.0 / (rand() % 10);
				if (b < 0.25)
					b = 1;
				glColor3f(0.5, (GLfloat)g, (GLfloat)b);
				glutSolidSphere((GLfloat)raza, 30, 36);

			}
}

void Rotatie() { //Rotatia planetelor
	glRotatef(Unghi, 0.0, 0.0, 1.0);
	if (Unghi < -360)
		Unghi = 360 + Unghi;
	else
			Unghi -= 0.1f;
}

void timer(int value) {
	glutPostRedisplay();
	glutTimerFunc(Timp, timer, 0);
}
